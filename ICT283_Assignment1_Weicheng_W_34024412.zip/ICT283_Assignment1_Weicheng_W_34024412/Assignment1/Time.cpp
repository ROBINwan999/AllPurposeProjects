#include "Time.h"

Time::Time() : hour_(0), minute_(0) {}

Time::Time(const int &hour, const int &minute) : hour_(hour), minute_(minute) {}

const int &Time::getHour() const {
    return hour_;
}

void Time::setHour(const int &hour) {
    hour_ = hour;
}

const int &Time::getMinute() const {
    return minute_;
}

void Time::setMinute(const int &minute) {
    minute_ = minute;
}
