#ifndef DATE_H
#define DATE_H

#include <iostream>

/**
 * @class Date
 * @brief  Manages all date info, it includes day, month and year
 * day contain day that get mark of the unit
 * month contain month that get mark of the unit
 * year contain year that get mark of the unit
 *
 * @author Weicheng Wan 34024412 (Preferred name: Robin)
 * @version 01
 * @date 19/03/2022
 *
 * @bug My program has no bugs. Well, maybe it has...
 */
class Date {
public:
    ///@brief  constructor, just initialize everything to empty state
    Date();

    /**
     * @brief constructor to set value for everything
     * @param const int &day
     * @param const int &month
     * @param const int &year
     */
    Date(const int &day, const int &month, const int &year);

    /**
     * @brief getter for day
     * @return const int &
     */
    const int &getDay() const;

    /**
     * @brief setter for day
     * @param const int &day
     * @return void
     */
    void setDay(const int &day);

    /**
     * @brief getter for month
     * @return const int &
     */
    const int &getMonth() const;

    /**
     * @brief setter for month
     * @param const int &month
     * @return void
     */
    void setMonth(const int &month);

    /**
     * @brief getter for year
     * @return const int &
     */
    const int &getYear() const;

    /**
     * setter for year
     * @param const int &
     * @return void
     */
    void setYear(const int &year);

private:
    ///day that get mark of the unit
    int day_;
    ///month that get mark of the unit
    int month_;
    ///year that get mark of the unit
    int year_;
};


#endif
