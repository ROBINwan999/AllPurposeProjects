#ifndef SENSOR_H
#define SENSOR_H

#include <iostream>

/**
 * @class Sensor
 * @brief  Manages all sensor info, it includes wind speed, temperature and solar radiation
 *
 * @author Weicheng Wan 34024412 (Preferred name: Robin)
 * @version 01
 * @date 02/04/2022
 *
 * @bug My program has no bugs. Well, maybe it has...
 */
class Sensor {
public:
    ///@brief constructor with no param, just initialize everything to empty state
    Sensor();

    /**
     * @brief constructor with param to set value for everything
     * @param const float &speed
     * @param const float &solar
     * @param const float &temperature
     */
    Sensor(const float &speed, const float &solar, const float &temperature);

    /**
     * @brief getter for wind speed
     * @return const float&
     */
    const float &getWindSpeed() const;


    /**
     * @brief setter for wind speed
     * @param const float &windSpeed
     * @return void
     */
    void setWindSpeed(const float &windSpeed);

    /**
     * @brief getter for solar radiation
     * @return const float &
     */
    const float &getSolarRadiation() const;

    /**
     * @brief setter for solar radiation
     * @param const float &solar
     * @return void
     */
    void setSolarRadiation(const float &solarRadiation);

    /**
     * @brief getter for temperature
     * @return const float &
     */
    const float &getTemperature() const;

    /**
     * @brief setter for temperature
     * @param const float &temperature
     * @return void
     */
    void setTemperature(const float &temperature);


private:
    ///wind speed
    float wind_speed_;
    ///solar radiation
    float solar_radiation_;
    ///temperature
    float temperature_;
};


#endif
