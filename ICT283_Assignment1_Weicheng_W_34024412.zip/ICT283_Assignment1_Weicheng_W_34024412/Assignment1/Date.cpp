#include "Date.h"

Date::Date() : day_(0), month_(0), year_(0) {}

Date::Date(const int &day, const int &month, const int &year) : day_(day), month_(month), year_(year) {}

const int &Date::getDay() const {
    return day_;
}

void Date::setDay(const int &day) {
    day_ = day;
}

const int &Date::getMonth() const {
    return month_;
}

void Date::setMonth(const int &month) {
    month_ = month;
}

const int &Date::getYear() const {
    return year_;
}

void Date::setYear(const int &year) {
    year_ = year;
}
