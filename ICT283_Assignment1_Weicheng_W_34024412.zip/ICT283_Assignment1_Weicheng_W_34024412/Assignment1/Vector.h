#ifndef VECTOR_H
#define VECTOR_H

#include <iostream>
#include <cstring>

/**
 * @class Vector
 * @tparam T
 * @brief  Manages Vector data structure, this is a dynamic array, it is a linear data structure, similar to
 * the standard template library one, but smaller and complete version.
 * There only the necessary functions are implemented.
 *
 * @author Weicheng Wan 34024412 (Preferred name: Robin)
 * @version nth version, I can't remember how many times change made to it
 * @date 19/03/2022
 *
 * @bug My program has no bugs. Well, maybe it has...
 */
template<class T>
class Vector {
public:
    /**
     * @brief this is constructor, it initialize a capacity 5 to the vector when declared
     * and also create a new space in heap
     */
    Vector();

    /**
     * @brief this is copy constructor, it is for copy initialization use.
     * @param const Vector &rhs
     */
    Vector(const Vector &rhs);

    /**
     * @brief this is assign operator overloading, it is for assign value to another vector
     * and it avoid shallow copy issue by creating a new heap memory space to store the copied value
     * @param const Vector &rhs
     * @return
     */
    Vector &operator=(const Vector &rhs);

    /**
     * @brief this is square bracket overloading, it is for so many use when people need to get index
     * @param int index
     * @return T &
     */
    T &operator[](int index) const;

    /**
     * @brief this is push back function, it add an element from end of the vector
     * @param T data
     * @return void
     */
    void push_back(T data);

    /**
     * @brief this is getter for the size/number of element in vector
     * @return int
     */
    int size() const;

    /**
     * @brief, it is for prevent memory leak as it needs to free the
     * allocated memory space and set everything to empty when destroy
     * the object each time, can destructor also use it, which increased code reuse
     */
    void clear();

    /**
     * @brief this is destructor
     */
    ~Vector();

private:
    ///a generic type pointer as a iterator to handle with every element in our container
    T *itr_;
    ///the capacity of our vector
    int max_size_;
    ///the currently actual element in our container
    int curr_size_;

    /**
     * @brief resize function to double our vector capacity each when it is full
     * @return void
     */
    void resize();
};

template<class T>
Vector<T>::Vector() {
    max_size_ = 5;
    curr_size_ = 0;
    itr_ = new T[max_size_];
}

template<class T>
Vector<T>::Vector(const Vector &rhs) {
    max_size_ = rhs.max_size_;
    curr_size_ = rhs.curr_size_;
    itr_ = new T[rhs.max_size_];
    memcpy(itr_, rhs.itr_, curr_size_ * sizeof(T));
}

template<class T>
Vector<T> &Vector<T>::operator=(const Vector &rhs) {
    clear();
    max_size_ = rhs.max_size_;
    curr_size_ = rhs.curr_size_;
    itr_ = new T[max_size_];
    memcpy(itr_, rhs.itr_, curr_size_ * sizeof(T));
}

template<class T>
T &Vector<T>::operator[](int index) const {
    return itr_[index];
}

template<class T>
void Vector<T>::push_back(T data) {
    if (curr_size_ == max_size_)
        resize();
    itr_[curr_size_] = data;
    curr_size_++;
}

template<class T>
int Vector<T>::size() const {
    return curr_size_;
}

template<class T>
void Vector<T>::clear() {
    if (itr_ != nullptr) {
        delete[]itr_;
        itr_ = nullptr;
        curr_size_ = 0;
        max_size_ = 0;
    }
}

template<class T>
Vector<T>::~Vector() {
    clear();
}

template<class T>
void Vector<T>::resize() {
    T *temp = new T[max_size_ * 2];
    for (int i = 0; i < curr_size_; i++) {
        temp[i] = itr_[i];
    }
    max_size_ *= 2;
    delete[] itr_;
    itr_ = new T[max_size_ * 2];
    for (int i = 0; i < curr_size_; i++) {
        itr_[i] = temp[i];
    }
}


#endif
