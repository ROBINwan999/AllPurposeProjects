#ifndef TIME_H
#define TIME_H

#include <iostream>

/**
 * @class Time
 * @brief  Manages all time info, it includes hour, minute
 * hour contain hour of the day
 * minute contain minute of the hour
 *
 * @author Weicheng Wan 34024412 (Preferred name: Robin)
 * @version 01
 * @date 30/03/2022
 *
 * @bug My program has no bugs. Well, maybe it has...
 */
class Time {
public:
    ///@brief  constructor, just initialize everything to empty state
    Time();

    /**
     * @brief constructor to set value for everything
     * @param const int &hour
     * @param const int &minute
     */
    Time(const int &hour, const int &minute);

    /**
     * getter for hour
     * @return const int &
     */
    const int &getHour() const;

    /**
     * setter for hour
     * @param const int &
     * @returen void
     */
    void setHour(const int &hour);

    /**
     * getter for minute
     * @return const int &
     */
    const int &getMinute() const;

    /**
     * setter for minute
     * @param const int &
     * @return void
     */
    void setMinute(const int &minute);

private:
    ///hour of the day
    int hour_;
    ///minute of the hour
    int minute_;
};


#endif
