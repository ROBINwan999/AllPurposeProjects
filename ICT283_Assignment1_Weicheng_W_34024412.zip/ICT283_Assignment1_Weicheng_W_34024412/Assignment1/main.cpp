#include "WindLogManager.h"

using std::cin;
using std::cout;
using std::endl;

enum WindLogOptions {//enum type for user to choose
    wind_information = 1,
    temperature_information = 2,
    solar_information = 3,
    write_all_info_into_csv = 4,
    exit_program = 5
};

int main() {
    WindLogManager W;//create a wind log manager object
    W.ScanFileName();//search file name
    W.ReadFromCSV();//read data from file and add into our vector

    int year, month;//store specified year and month from user input
    int user_option;//for store user selection

    while (true) {//let user keep selecting until they want to exit

        W.PrintMenu();//print the menu option

        cout << "Please enter your choice: " << endl;
        cin >> user_option;//get option from user

        if (cin.fail()) {//if enter something not int, program exit
            cout << "Error input!" << endl;
            exit(0);
        }

        switch (user_option) {
            case wind_information: {
                year = W.get_year_number();//for a specified year
                month = W.get_month_number();//and a specified month
                Vector<Vector<float>> monthly_wind_speed = W.get_monthly_wind_speed(year);
                W.TransMPSToKMPH(monthly_wind_speed);
                Vector<float> monthly_wind_speed_sum = W.get_monthly_wind_speed_sum(monthly_wind_speed);
                Vector<float> monthly_wind_speed_mean = W.get_monthly_wind_speed_mean(monthly_wind_speed,
                                                                                      monthly_wind_speed_sum);
                Vector<float> monthly_wind_speed_sample_stdev = W.get_monthly_wind_speed_sample_stdev(
                        monthly_wind_speed, monthly_wind_speed_mean);
                W.PrintWindInfo(monthly_wind_speed_mean, monthly_wind_speed_sample_stdev, year, month);
            }
                break;
            case temperature_information: {
                year = W.get_year_number();//for each month of a specified year
                Vector<Vector<float>> monthly_temperature = W.get_monthly_temperature(year);
                Vector<float> monthly_temperature_sum = W.get_monthly_temperature_sum(monthly_temperature);
                Vector<float> monthly_temperature_mean = W.get_monthly_temperature_mean(monthly_temperature,
                                                                                        monthly_temperature_sum);
                Vector<float> monthly_temperature_sample_stdev = W.get_monthly_temperature_sample_stdev(
                        monthly_temperature, monthly_temperature_mean);
                W.PrintTemperatureInfo(year, monthly_temperature_mean,
                                       monthly_temperature_sample_stdev);
            }
                break;
            case solar_information: {
                year = W.get_year_number();//for each month of a specified year
                Vector<Vector<float>> monthly_solar_radiation = W.get_monthly_solar_radiation(year);
                Vector<float> monthly_solar_radiation_sum = W.get_monthly_solar_radiation_sum(monthly_solar_radiation);
                W.ConvertUnitForSolarRadiation(monthly_solar_radiation_sum);
                W.PrintSolarRadiationInfo(monthly_solar_radiation_sum, year);
            }
                break;
            case write_all_info_into_csv: {
                year = W.get_year_number();//for a specified year
                Vector<Vector<float>> monthly_wind_speed = W.get_monthly_wind_speed(year);
                W.TransMPSToKMPH(monthly_wind_speed);
                Vector<float> monthly_wind_speed_sum = W.get_monthly_wind_speed_sum(monthly_wind_speed);
                Vector<float> monthly_wind_speed_mean = W.get_monthly_wind_speed_mean(monthly_wind_speed,
                                                                                      monthly_wind_speed_sum);
                Vector<float> monthly_wind_speed_sample_stdev = W.get_monthly_wind_speed_sample_stdev(
                        monthly_wind_speed, monthly_wind_speed_mean);
                //get each month temperature data for a specified year
                Vector<Vector<float>> monthly_temperature = W.get_monthly_temperature(year);
                Vector<float> monthly_temperature_sum = W.get_monthly_temperature_sum(monthly_temperature);
                Vector<float> monthly_temperature_mean = W.get_monthly_temperature_mean(monthly_temperature,
                                                                                        monthly_temperature_sum);
                Vector<float> monthly_temperature_sample_stdev = W.get_monthly_temperature_sample_stdev(
                        monthly_temperature, monthly_temperature_mean);
                //get each month solar radiation data for a specified year
                Vector<Vector<float>> monthly_solar_radiation = W.get_monthly_solar_radiation(year);
                Vector<float> monthly_solar_radiation_sum = W.get_monthly_solar_radiation_sum(monthly_solar_radiation);
                W.ConvertUnitForSolarRadiation(monthly_solar_radiation_sum);
                //print data into a file called WindTempSolar.csv
                W.WriteIntoCSV(year, monthly_wind_speed_mean, monthly_wind_speed_sample_stdev, monthly_temperature_mean,
                               monthly_temperature_sample_stdev, monthly_solar_radiation_sum);
            }
                break;
            case exit_program:
                cout << "Thanks for using! see you next time!" << endl;
                exit(0);
            default://if user enter a number other than option 1-5 will print tips to let user enter again
                cout << "Please enter correct option!" << endl;
                break;
        }
        //To keep the console clean, after each output, press any key to clear the screen
        system("pause");
        system("cls");
    }

}
