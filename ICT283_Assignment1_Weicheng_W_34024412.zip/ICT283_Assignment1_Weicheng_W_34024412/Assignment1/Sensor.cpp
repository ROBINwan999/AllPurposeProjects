#include "Sensor.h"

Sensor::Sensor() : wind_speed_(0), solar_radiation_(0), temperature_(0) {}

Sensor::Sensor(const float &speed, const float &solar, const float &temperature) : wind_speed_(speed),
                                                                                   solar_radiation_(solar),
                                                                                   temperature_(temperature) {}

const float &Sensor::getWindSpeed() const {
    return wind_speed_;
}

void Sensor::setWindSpeed(const float &windSpeed) {
    wind_speed_ = windSpeed;
}

const float &Sensor::getSolarRadiation() const {
    return solar_radiation_;
}

void Sensor::setSolarRadiation(const float &solarRadiation) {
    solar_radiation_ = solarRadiation;
}

const float &Sensor::getTemperature() const {
    return temperature_;
}

void Sensor::setTemperature(const float &temperature) {
    temperature_ = temperature;
}
