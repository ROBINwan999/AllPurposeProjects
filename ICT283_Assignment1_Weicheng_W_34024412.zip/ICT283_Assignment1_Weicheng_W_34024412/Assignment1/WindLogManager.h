#ifndef WINDLOGMANAGER_H
#define WINDLOGMANAGER_H

#include "WindLogType.h"
#include "Vector.h"
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>

/**
 * @class WindLogManager
 * @brief  Encapsulates wind log type data and manages operations on the data
 *
 * @author Weicheng Wan 34024412 (Preferred name: Robin)
 * @version 01
 * @date 16/04/2022
 *
 * @bug My program has no bugs. Well, maybe it has...
 */
class WindLogManager {
public:

    /**
     * @brief default constructor
     */
    WindLogManager() = default;

    /**
     * @brief print menu option to the user
     * @return void
     */
    void PrintMenu();

    /**
     * @brief this is to get file names in the txt file as many as provided
     * @return void
     */
    void ScanFileName();

    /**
     * @brief this is to reading the csv file into wind log vector
     * @return void
     */
    void ReadFromCSV();

    /**
     * @brief this is to do the cutting each line of data to get the data we needed
     * @param wind_speed_index
     * @param solar_radiation_index
     * @param temperature_index
     * @param file_data
     * @return void
     */
    void LoadingData(int wind_speed_index, int solar_radiation_index, int temperature_index,
                     const Vector<std::string> &file_data);

    /**
     * @brief this is to get the index of wind,solar,temperature, so that program can read different file order
     * @param wind_speed_index
     * @param solar_index
     * @param temperature_index
     * @param heading
     * @return void
     */
    void SmartOrder(int &wind_speed_index, int &solar_index, int &temperature_index, const std::string &heading);

    /**
     * @brief this is to get the user specified year
     * @return int
     */
    int get_year_number();

    /**
     * @brief this is to get the user specified month
     * @return int
     */
    int get_month_number();

    /**
     * @brief this is to get the English month word for user specified month
     * @param month
     * @return string
     */
    std::string get_English_month_word(int month);

    /**
     * @brief this it to get each month wind speed data for user specified year
     * @param year
     * @return Vector<Vector<float>>
     */
    Vector<Vector<float>> get_monthly_wind_speed(int year);

    /**
     * @brief this is convert unit from m/s into km/h
     * @param monthly_wind_speed
     * @return void
     */
    void TransMPSToKMPH(Vector<Vector<float>> &monthly_wind_speed);

    /**
     * @brief this it to get each month wind speed sum for user specified year
     * @param monthly_wind_speed
     * @return Vector<float>
     */
    Vector<float> get_monthly_wind_speed_sum(const Vector<Vector<float>> &monthly_wind_speed);

    /**
     * @brief this it to get each month wind speed mean for user specified year
     * @param monthly_wind_speed
     * @param monthly_wind_speed_sum
     * @return Vector<float>
     */
    Vector<float> get_monthly_wind_speed_mean(const Vector<Vector<float>> &monthly_wind_speed,
                                              const Vector<float> &monthly_wind_speed_sum);

    /**
     * @brief this it to get each month wind speed sample standard deviation for user specified year
     * @param monthly_wind_speed
     * @param monthly_wind_speed_mean
     * @return Vector<float>
     */
    Vector<float> get_monthly_wind_speed_sample_stdev(const Vector<Vector<float>> &monthly_wind_speed,
                                                      const Vector<float> &monthly_wind_speed_mean);

    /**
     * @brief this is to print result for menu option 1 as required format
     * @param monthly_wind_speed_mean
     * @param monthly_wind_speed_sample_stdev
     * @param year
     * @param month
     * @return void
     */
    void PrintWindInfo(const Vector<float> &monthly_wind_speed_mean,
                       const Vector<float> &monthly_wind_speed_sample_stdev, int year, int month);

    /**
     * @brief this it to get each month temperature data for user specified year
     * @param year
     * @return Vector<Vector<float>>
     */
    Vector<Vector<float>> get_monthly_temperature(int year);

    /**
     * @brief this it to get each month temperature sum for user specified year
     * @param monthly_temperature
     * @return Vector<float>
     */
    Vector<float> get_monthly_temperature_sum(const Vector<Vector<float>> &monthly_temperature);

    /**
     * @brief this it to get each month temperature month for user specified year
     * @param monthly_temperature
     * @param monthly_temperature_sum
     * @return Vector<float>
     */
    Vector<float> get_monthly_temperature_mean(const Vector<Vector<float>> &monthly_temperature,
                                               const Vector<float> &monthly_temperature_sum);

    /**
     * @brief this it to get each month temperature sample standard deviation for user specified year
     * @param monthly_temperature
     * @param monthly_temperature_mean
     * @return Vector<float>
     */
    Vector<float> get_monthly_temperature_sample_stdev(const Vector<Vector<float>> &monthly_temperature,
                                                       const Vector<float> &monthly_temperature_mean);

    /**
     * @brief this is to print menu option 2 as required format
     * @param year
     * @param monthly_temperature_sample_stdev
     * @param monthly_temperature_mean
     * @return void
     */
    void PrintTemperatureInfo(int year, const Vector<float> &monthly_temperature_sample_stdev,
                              const Vector<float> &monthly_temperature_mean);

    /**
     * @brief this it to get each month solar radiation data for user specified year
     * @param year
     * @return Vector<Vector<float>>
     */
    Vector<Vector<float>> get_monthly_solar_radiation(int year);

    /**
     * @brief this it to get each month solar radiation sum for user specified year
     * @param monthly_solar_radiation
     * @return Vector<float>
     */
    Vector<float> get_monthly_solar_radiation_sum(Vector<Vector<float>> &monthly_solar_radiation);

    /**
     * @brief this is to convert unit from W/m^2 to kWh/m^2
     * @param monthly_solar_radiation_sum
     * @return void
     */
    void ConvertUnitForSolarRadiation(Vector<float> &monthly_solar_radiation_sum);

    /**
     * @brief this is to print menu option 3 as required format
     * @param monthly_solar_radiation_sum
     * @param year
     * @return void
     */
    void PrintSolarRadiationInfo(const Vector<float> &monthly_solar_radiation_sum, int year);

    /**
     * @brief this is to check is there year record in csv file
     * @param year
     * @return bool
     */
    bool IsYearValid(int year);

    /**
     * @brief this is to print menu option into a csv file as required format
     * @param year
     * @param monthly_wind_speed_mean
     * @param monthly_wind_speed_sample_stdev
     * @param monthly_temperature_mean
     * @param monthly_temperature_sample_stdev
     * @param monthly_solar_radiation_sum
     * @return void
     */
    void WriteIntoCSV(int year,
                      const Vector<float> &monthly_wind_speed_mean,
                      const Vector<float> &monthly_wind_speed_sample_stdev,
                      const Vector<float> &monthly_temperature_mean,
                      const Vector<float> &monthly_temperature_sample_stdev,
                      const Vector<float> &monthly_solar_radiation_sum);

private:
    ///vector for store file names
    Vector<std::string> file_name_list;
    ///vector for store wind log type data
    Vector<WindLogType> wind_log;
};

#endif
