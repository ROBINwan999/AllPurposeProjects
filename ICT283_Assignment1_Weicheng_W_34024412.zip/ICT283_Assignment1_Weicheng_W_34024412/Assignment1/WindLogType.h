#ifndef WINDLOGTYPE_H
#define WINDLOGTYPE_H

#include "Date.h"
#include "Time.h"
#include "Sensor.h"

/**
 * @class WindLogType
 * @brief  Manages all the Date, Time, Sensor object member
 * A layer of abstract class in logic design, by abstract, I mean the ADT level, not the real pure virtual function
 * and not the actual physical machine storage level
 *
 * @author Weicheng Wan 34024412 (Preferred name: Robin)
 * @version 01
 * @date 02/04/2022
 *
 * @bug My program has no bugs. Well, maybe it has...
 */
class WindLogType {
public:
    ///@brief constructor with no param, just use the default version
    WindLogType() = default;

    /**
     * @brief constructor with param to set value for everything
     * @param const Date &date
     * @param const Time &time
     * @param const Sensor &sensor
     */
    WindLogType(const Date &date, const Time &time, const Sensor &sensor);

    /**
     * @brief getter for Date object
     * @return const Date &
     */
    const Date &getDate() const;

    /**
     * @brief setter for Date object
     * @param const Date &date
     * @return void
     */
    void setDate(const Date &date);

    /**
     * @brief getter for Time object
     * @return const Time &
     */
    const Time &getTime() const;

    /**
     * @brief setter for Time object
     * @param const Time &time
     * @return void
     */
    void setTime(const Time &time);

    /**
     * @brief getter for Sensor object
     * @return const Sensor &
     */
    const Sensor &getSensor() const;

    /**
     * @brief setter for Sensor object
     * @param const Sensor &sensor
     * @return void
     */
    void setSensor(const Sensor &sensor);

private:
    //Date class object member
    Date date_;
    //Time class object member
    Time time_;
    //Sensor class object member
    Sensor sensor_;
};


#endif
