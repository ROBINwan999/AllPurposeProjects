#include "WindLogType.h"

WindLogType::WindLogType(const Date &date, const Time &time, const Sensor &sensor) : date_(date), time_(time),
                                                                                     sensor_(sensor) {}

const Date &WindLogType::getDate() const {
    return date_;
}

void WindLogType::setDate(const Date &date) {
    date_ = date;
}

const Time &WindLogType::getTime() const {
    return time_;
}

void WindLogType::setTime(const Time &time) {
    time_ = time;
}

const Sensor &WindLogType::getSensor() const {
    return sensor_;
}

void WindLogType::setSensor(const Sensor &sensor) {
    sensor_ = sensor;
}
