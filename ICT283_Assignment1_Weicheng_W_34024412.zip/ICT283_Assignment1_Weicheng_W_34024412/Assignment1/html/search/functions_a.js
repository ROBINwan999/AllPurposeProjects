var searchData=
[
  ['time_172',['Time',['../class_time.html#a4245e409c7347d1d671858962c2ca3b5',1,'Time::Time()'],['../class_time.html#a513a027ca13d25a501de1d0e5ca6de3b',1,'Time::Time(const int &amp;hour, const int &amp;minute)']]],
  ['transmpstokmph_173',['TransMPSToKMPH',['../class_wind_log_manager.html#a20813dc572229f27c7b0f8e736796692',1,'WindLogManager']]]
];
