var searchData=
[
  ['isyearvalid_145',['IsYearValid',['../class_wind_log_manager.html#af4b47574799b094a519af70cdaabb099',1,'WindLogManager']]]
];
