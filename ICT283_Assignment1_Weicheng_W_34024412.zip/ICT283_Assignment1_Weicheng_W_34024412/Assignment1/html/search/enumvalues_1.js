var searchData=
[
  ['solar_5finformation_197',['solar_information',['../main_8cpp.html#a23c88b0ad412ed2ec19edc9c7ccb9a4fae76c18e1fa938091cdc69b6a95eb85ba',1,'main.cpp']]]
];
