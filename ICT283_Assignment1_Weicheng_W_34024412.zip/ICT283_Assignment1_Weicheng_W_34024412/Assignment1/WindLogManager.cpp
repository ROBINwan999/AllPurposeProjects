//
// Created by 94013 on 2022/4/17.
//

#include "WindLogManager.h"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;
using std::setprecision;
using std::stringstream;
using std::invalid_argument;

void WindLogManager::PrintMenu() {
    cout << "***********************************" << endl;
    cout << "Welcome to the Sensor Data Query System!" << endl;
    cout << "1. ----- Query wind speed data" << endl;
    cout << "2. ----- Query temperature data" << endl;
    cout << "3. ----- Query solar radiation data" << endl;
    cout << "4. ----- Save all data into csv file" << endl;
    cout << "5. ----- Exit the program" << endl;
    cout << "***********************************" << endl;
}

void WindLogManager::ScanFileName() {
    ifstream ifs("data\\file_name.txt");
    if (!ifs) {//if file do not exist, then print error message and exit program
        cout << "File: 'file_name.txt' not found!" << endl;
        exit(0);
    }

    cout << "Searching for file names ... ";//Prompt the user what happened while waiting

    string temp;
    while (ifs.good()) {
        getline(ifs, temp);//get all file name and add into our file name list vector
        file_name_list.push_back(temp);
    }
    ifs.close();

    //Prompt the user what happened while waiting
    cout << "find the following file names: " << endl;
    cout << "-----------------------------------" << endl;
    for (int i = 0; i < file_name_list.size(); ++i) {
        cout << "'" << file_name_list[i] << "'" << endl;
    }
    cout << "-----------------------------------" << endl;
    cout << "Start loading file, please wait ..." << endl;
    cout << "-----------------------------------" << endl;
}

void WindLogManager::ReadFromCSV() {
    int wind_speed_index, solar_radiation_index, temperature_index;//get these columns index in the csv file

    for (int i = 0; i < file_name_list.size(); ++i) {//Traverse the file list to get all files
        //Prompt the user what happened while waiting
        cout << "Loading the data for " << "'" << file_name_list[i] << "'" << endl;
        Vector<string> file_data;//temp vector to store the data for each file

        ifstream ifs("data\\" + file_name_list[i]);//our files are under the data dir
        if (!ifs) {
            cout << "File: '" << file_name_list[i] << "' not found!" << endl;
            exit(0);
        }

        string temp;
        getline(ifs, temp);//get the first line
        SmartOrder(wind_speed_index, solar_radiation_index, temperature_index, temp);
        while (ifs.good()) {
            getline(ifs, temp);
            file_data.push_back(temp);
            ifs.peek();
        }
        ifs.close();

        //finish read current file, immediately start cutting,
        //otherwise continue read second file, the data order is different.
        //all wrong data, and the index is second file index, then becomes pointless
        LoadingData(wind_speed_index, solar_radiation_index, temperature_index, file_data);

        file_data.clear();//then clear it, for storing next file use
    }

    for (int i = 0; i < file_name_list.size(); ++i) {

    }
    //Prompt the user what happened while waiting
    cout << "-----------------------------------" << endl;
    cout << "Data loaded successfully!" << endl;
}

void WindLogManager::LoadingData(int wind_speed_index, int solar_radiation_index, int temperature_index,
                                 const Vector<string> &file_data) {
    //smart segmentation according to the index calculated by smart order function
    for (int i = 0; i < file_data.size(); ++i) {
        stringstream ss(file_data[i]);
        WindLogType w;
        Date date;
        Time time;
        Sensor sensor;
        string temp;

        try {//deal with invalid argument exception
            getline(ss, temp, '/');
            if (temp[0] == ',')continue; //if the first char is a common, it means it is empty line
            // we can use continue to skip over this empty line since this is in a loop
            date.setDay(stoi(temp));
            getline(ss, temp, '/');
            date.setMonth(stoi(temp));
            getline(ss, temp, ' ');
            date.setYear(stoi(temp));

            getline(ss, temp, ':');
            time.setHour(stoi(temp));
            getline(ss, temp, ',');
            time.setMinute(stoi(temp));

            //after calculation, always cut (wind speed index -1) times to get correct wind speed data
            for (int a = 0; a < wind_speed_index - 1; ++a) {
                getline(ss, temp, ',');
            }
            getline(ss, temp, ',');
            sensor.setWindSpeed(stof(temp));
            //after calculation, always cut (solar radiation index - wind speed index -1) times
            //to get correct temperature data
            for (int b = 0; b < solar_radiation_index - wind_speed_index - 1; b++) {
                getline(ss, temp, ',');
            }
            getline(ss, temp, ',');
            sensor.setSolarRadiation(stof(temp));
            //after calculation, always cut (temperature index - solar radiation index -1) times
            //to get correct solar radiation data
            if (temperature_index == 17) {//if index is 17 means it iss the last element in the line
                for (int c = 0; c < temperature_index - solar_radiation_index - 1; c++) {
                    getline(ss, temp, ',');
                }
                getline(ss, temp, '\n');//we cut by new line character
                sensor.setTemperature(stof(temp));
            } else {//if it is not the last one, just cut how many times as it needs to, then get rest of the line
                for (int d = 0; d < temperature_index - solar_radiation_index - 1; d++) {
                    getline(ss, temp, ',');
                }
                getline(ss, temp, ',');
                sensor.setTemperature(stof(temp));
                getline(ss, temp);
            }
        } catch (invalid_argument &) {//if catch any invalid argument exception
            cout << "";
        }

        w.setDate(date);
        w.setTime(time);
        w.setSensor(sensor);

        //add into our wind log vector
        wind_log.push_back(w);

    }

}

void
WindLogManager::SmartOrder(int &wind_speed_index, int &solar_index, int &temperature_index, const string &heading) {
    //smart order is calculating the index of wind speed, solar radiation and temperature in each csv file
    Vector<string> heading_into_pieces;

    stringstream ss(heading);
    string temp;
    while (getline(ss, temp, ',')) {//separate our heading
        heading_into_pieces.push_back(temp);//add pieces into our heading vector
    }

    //traverse the heading vector to get index
    for (int i = 0; i < heading_into_pieces.size(); i++) {
        if (heading_into_pieces[i] == "S") wind_speed_index = i;
        if (heading_into_pieces[i] == "SR") solar_index = i;
        if (heading_into_pieces[i] == "T") temperature_index = i;
    }
}

int WindLogManager::get_year_number() {
    int year;//year number

    cout << "Please enter a year: " << endl;
    cin >> year;

    if (cin.fail()) {//if enters something not int, program exit
        cout << "Error input!" << endl;
        exit(0);
    } else {
        return year;
    }
}

int WindLogManager::get_month_number() {
    int month;//month number

    while (true) {//let user keep entering month number until it is a valid month
        cout << "Please enter a month: " << endl;
        cin >> month;

        if (cin.fail()) {//if enter something not int, program exit
            cout << "Error input!" << endl;
            exit(0);
        }

        if (month >= 1 && month <= 12)
            return month;//month is valid
        else
            cout << "Invalid month number, please enter again!" << endl;//month is not valid
    }

}

string WindLogManager::get_English_month_word(int month) {
    string EnglishMonth[] = {"noNeedForZero", "January", "February",
                             "March", "April", "May",
                             "June", "July", "August",
                             "September", "October", "November",
                             "December"};
    //return element by the index, for e.g. month = 5, and EnglishMonth[5] = May, so return value is May, etc.
    return EnglishMonth[month];
}


Vector<Vector<float>> WindLogManager::get_monthly_wind_speed(int year) {
    Vector<float> jan, feb, mar, apr, may, jun, jul, agu, sep, oct, nov, dec;//12 vector for each month wind speed

    for (int i = 0; i < wind_log.size(); ++i) {
        if (wind_log[i].getDate().getYear() == year) {//if the year match with user specified year
            //wind_log[i].getDate().getMonth() is too long, so use a var called month instead
            int month = wind_log[i].getDate().getMonth();
            if (month == 1)jan.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 2)feb.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 3)mar.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 4)apr.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 5)may.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 6)jun.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 7)jul.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 8)agu.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 9)sep.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 10)oct.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 11)nov.push_back(wind_log[i].getSensor().getWindSpeed());
            if (month == 12)dec.push_back(wind_log[i].getSensor().getWindSpeed());
        }
    }

    //result 2D vector to store each month wind speed data for a specified year
    Vector<Vector<float>> monthly_wind_speed;

    //add our each month wind speed data into our result vector
    monthly_wind_speed.push_back(jan);
    monthly_wind_speed.push_back(feb);
    monthly_wind_speed.push_back(mar);
    monthly_wind_speed.push_back(apr);
    monthly_wind_speed.push_back(may);
    monthly_wind_speed.push_back(jun);
    monthly_wind_speed.push_back(jul);
    monthly_wind_speed.push_back(agu);
    monthly_wind_speed.push_back(sep);
    monthly_wind_speed.push_back(oct);
    monthly_wind_speed.push_back(nov);
    monthly_wind_speed.push_back(dec);

    return monthly_wind_speed;//return our result vector
}

void WindLogManager::TransMPSToKMPH(Vector<Vector<float>> &monthly_wind_speed) {
    for (int i = 0; i < monthly_wind_speed.size(); ++i) {
        for (int j = 0; j < monthly_wind_speed[i].size(); ++j) {
            monthly_wind_speed[i][j] *= 3.6;
        }
    }
}

Vector<float> WindLogManager::get_monthly_wind_speed_sum(const Vector<Vector<float>> &monthly_wind_speed) {
    Vector<float> monthly_wind_speed_sum;//vector for store each month speed sum
    float speed_sum;//one month speed sum

    for (int i = 0; i < monthly_wind_speed.size(); i++) {
        for (int j = 0; j < monthly_wind_speed[i].size(); j++) {
            if (monthly_wind_speed[i].size() == 0)//if this month is 0, it means no data
                monthly_wind_speed_sum.push_back(0);//then we push back 0 into our vector
            else//if not 0, means this month has data, we get speed sum for this month
                speed_sum += monthly_wind_speed[i][j];
        }
        monthly_wind_speed_sum.push_back(speed_sum);//add sum into our result vector
        speed_sum = 0;//empty this month's sum for next month calculation
    }

    return monthly_wind_speed_sum;//return our result vector

}

Vector<float> WindLogManager::get_monthly_wind_speed_mean(const Vector<Vector<float>> &monthly_wind_speed,
                                                          const Vector<float> &monthly_wind_speed_sum) {
    float wind_speed_mean;//one month wind speed sum
    Vector<float> monthly_wind_speed_mean;//vector for store each month wind speed sum

    for (int i = 0; i < monthly_wind_speed_sum.size(); ++i) {
        if (monthly_wind_speed[i].size() == 0) {//if this month has 0 element, that means this month has no data
            monthly_wind_speed_mean.push_back(0);//then just add a zero into our res vec
        } else {//if this month has data
            wind_speed_mean = monthly_wind_speed_sum[i] / (float) monthly_wind_speed[i].size();//calculate mean
            monthly_wind_speed_mean.push_back(wind_speed_mean);//and then add into our res vec
        }
    }

    return monthly_wind_speed_mean;//return our result vector
}

Vector<float> WindLogManager::get_monthly_wind_speed_sample_stdev(const Vector<Vector<float>> &monthly_wind_speed,
                                                                  const Vector<float> &monthly_wind_speed_mean) {
    float wind_speed_sample_variance, wind_speed_sample_stdev;//sample variance and sample stdev for wind speed
    Vector<float> monthly_wind_speed_sample_stdev;//store each month wind speed sample standard deviation

    for (int i = 0; i < monthly_wind_speed.size(); i++) {
        //if this row has 0 element, that means no data for this month, for example jan and feb in 2014
        if (monthly_wind_speed[i].size() == 0) {
            monthly_wind_speed_sample_stdev.push_back(0);
        } else {//if not 0 element, start calculating for each month
            for (int j = 0; j < monthly_wind_speed[i].size(); j++) {
                wind_speed_sample_variance +=
                        pow((monthly_wind_speed[i][j] - monthly_wind_speed_mean[i]), 2);
            }
            if (monthly_wind_speed[i].size() != 0) {
                wind_speed_sample_variance /= (float) monthly_wind_speed[i].size();
            }
            wind_speed_sample_stdev = sqrt(wind_speed_sample_variance);
            monthly_wind_speed_sample_stdev.push_back(wind_speed_sample_stdev);//add result into our res vec
            wind_speed_sample_variance = 0;//and set it to 0 for next month calculation
        }
    }

    return monthly_wind_speed_sample_stdev;//return our result vector
}

void WindLogManager::PrintWindInfo(const Vector<float> &monthly_wind_speed_mean,
                                   const Vector<float> &monthly_wind_speed_sample_stdev, int year, int month) {
    //print output as assignment required format
    if (monthly_wind_speed_mean[month - 1] == 0 || monthly_wind_speed_sample_stdev[month - 1] == 0) {
        cout << get_English_month_word(month) << " " << year << ": No Data" << endl;
    } else {
        cout << get_English_month_word(month) << " " << year << ":" << endl;
        cout << "Average speed: " << setprecision(3) << monthly_wind_speed_mean[month - 1] << " km/h" << endl;
        cout << "Sample stdev: " << setprecision(3) << monthly_wind_speed_sample_stdev[month - 1] << endl;
    }
}


Vector<Vector<float>> WindLogManager::get_monthly_temperature(int year) {
    Vector<float> jan, feb, mar, apr, may, jun, jul, agu, sep, oct, nov, dec;//12 vector for each month temperature

    for (int i = 0; i < wind_log.size(); ++i) {
        if (wind_log[i].getDate().getYear() == year) {//if the year match with user specified year
            //wind_log[i].getDate().getMonth() is too long, so use a var called month instead
            int month = wind_log[i].getDate().getMonth();
            if (month == 1)jan.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 2)feb.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 3)mar.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 4)apr.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 5)may.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 6)jun.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 7)jul.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 8)agu.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 9)sep.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 10)oct.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 11)nov.push_back(wind_log[i].getSensor().getTemperature());
            if (month == 12)dec.push_back(wind_log[i].getSensor().getTemperature());
        }
    }

    //result 2D vector to store each month temperature data for a specified year
    Vector<Vector<float>> monthly_temperature;

    //add our each month temperature data into our result vector
    monthly_temperature.push_back(jan);
    monthly_temperature.push_back(feb);
    monthly_temperature.push_back(mar);
    monthly_temperature.push_back(apr);
    monthly_temperature.push_back(may);
    monthly_temperature.push_back(jun);
    monthly_temperature.push_back(jul);
    monthly_temperature.push_back(agu);
    monthly_temperature.push_back(sep);
    monthly_temperature.push_back(oct);
    monthly_temperature.push_back(nov);
    monthly_temperature.push_back(dec);

    return monthly_temperature;//return our result vector
}

Vector<float> WindLogManager::get_monthly_temperature_sum(const Vector<Vector<float>> &monthly_temperature) {
    Vector<float> monthly_temperature_sum;//vector for store each month temperature sum
    float temperature_sum;//one month temperature sum

    for (int i = 0; i < monthly_temperature.size(); i++) {
        for (int j = 0; j < monthly_temperature[i].size(); j++) {
            if (monthly_temperature[i].size() == 0)//if this month is 0, it means no data
                monthly_temperature_sum.push_back(0);//then we push back 0 into our vector
            else//if not 0, means this month has data, we get temperature sum for this month
                temperature_sum += monthly_temperature[i][j];
        }
        monthly_temperature_sum.push_back(temperature_sum);//add sum into our result vector
        temperature_sum = 0;//empty this month's sum for next month calculation
    }

    return monthly_temperature_sum;//return our result vector
}

Vector<float> WindLogManager::get_monthly_temperature_mean(const Vector<Vector<float>> &monthly_temperature,
                                                           const Vector<float> &monthly_temperature_sum) {
    float temperature_sum;//one month temperature sum
    Vector<float> monthly_temperature_mean;//vector for store each month temperature sum

    for (int i = 0; i < monthly_temperature_sum.size(); ++i) {
        if (monthly_temperature[i].size() == 0) {//if this month has 0 element, that means this month has no data
            monthly_temperature_mean.push_back(0);//then just add a zero into our res vec
        } else {//if this month has data
            temperature_sum = monthly_temperature_sum[i] / (float) monthly_temperature[i].size();//calculate mean
            monthly_temperature_mean.push_back(temperature_sum);//and then add into our res vec
        }
    }

    return monthly_temperature_mean;//return our result vector
}

Vector<float> WindLogManager::get_monthly_temperature_sample_stdev(const Vector<Vector<float>> &monthly_temperature,
                                                                   const Vector<float> &monthly_temperature_mean) {
    float temperature_sample_variance, temperature_sample_stdev;//sample variance and sample stdev for temperature
    Vector<float> monthly_temperature_sample_stdev;//store each month temperature sample standard deviation

    for (int i = 0; i < monthly_temperature.size(); i++) {
        //if this row has 0 element, that means no data for this month, for example jan and feb in 2014
        if (monthly_temperature[i].size() == 0) {
            monthly_temperature_sample_stdev.push_back(0);
        } else {//if not 0 element, start calculating for each month
            for (int j = 0; j < monthly_temperature[i].size(); j++) {
                temperature_sample_variance += pow((monthly_temperature[i][j] - monthly_temperature_mean[i]), 2);
            }
            if (monthly_temperature[i].size() != 0) {
                temperature_sample_variance /= (float) monthly_temperature[i].size();
            }
            temperature_sample_stdev = sqrt(temperature_sample_variance);
            monthly_temperature_sample_stdev.push_back(temperature_sample_stdev);//add result into our res vec
            temperature_sample_variance = 0;//and set it to 0 for next month calculation
        }
    }

    return monthly_temperature_sample_stdev;//return our result vector
}

void WindLogManager::PrintTemperatureInfo(int year, const Vector<float> &monthly_temperature_sample_stdev,
                                          const Vector<float> &monthly_temperature_mean) {
    //print output as required format
    cout << year << endl;
    for (int i = 0; i < 12; ++i) {
        if (monthly_temperature_mean[i] == 0 || monthly_temperature_sample_stdev[i] == 0) {
            cout << get_English_month_word(i + 1) << ": No Data" << endl;
        } else {
            cout << get_English_month_word(i + 1) << ": average: " << setprecision(3)
                 << monthly_temperature_mean[i] << " degree C, stdev: " << setprecision(3)
                 << monthly_temperature_sample_stdev[i] << endl;
        }
    }
}

Vector<Vector<float>> WindLogManager::get_monthly_solar_radiation(int year) {
    //12 vector for each month solar radiation
    Vector<float> jan, feb, mar, apr, may, jun, jul, agu, sep, oct, nov, dec;

    for (int i = 0; i < wind_log.size(); ++i) {
        if (wind_log[i].getDate().getYear() == year) {//if the year match with user specified year
            //wind_log[i].getDate().getMonth() is too long, so use a var called month instead
            int month = wind_log[i].getDate().getMonth();
            if (month == 1)jan.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 2)feb.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 3)mar.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 4)apr.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 5)may.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 6)jun.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 7)jul.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 8)agu.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 9)sep.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 10)oct.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 11)nov.push_back(wind_log[i].getSensor().getSolarRadiation());
            if (month == 12)dec.push_back(wind_log[i].getSensor().getSolarRadiation());
        }
    }

    //result 2D vector to store each month solar radiation data for a specified year
    Vector<Vector<float>> monthly_solar_radiation;

    //add our each month solar radiation data into our result vector
    monthly_solar_radiation.push_back(jan);
    monthly_solar_radiation.push_back(feb);
    monthly_solar_radiation.push_back(mar);
    monthly_solar_radiation.push_back(apr);
    monthly_solar_radiation.push_back(may);
    monthly_solar_radiation.push_back(jun);
    monthly_solar_radiation.push_back(jul);
    monthly_solar_radiation.push_back(agu);
    monthly_solar_radiation.push_back(sep);
    monthly_solar_radiation.push_back(oct);
    monthly_solar_radiation.push_back(nov);
    monthly_solar_radiation.push_back(dec);

    return monthly_solar_radiation;//return our result vector
}

Vector<float> WindLogManager::get_monthly_solar_radiation_sum(Vector<Vector<float>> &monthly_solar_radiation) {
    Vector<float> count_each_month_solar_radiation;//get size for each month
    for (int i = 0; i < monthly_solar_radiation.size(); i++) {
        count_each_month_solar_radiation.push_back((float) monthly_solar_radiation[i].size());
    }

    float solar_radiation_sum;//one month solar radiation sum
    Vector<float> monthly_solar_radiation_sum;//vector for store each month solar radiation sum

    for (int i = 0; i < monthly_solar_radiation.size(); i++) {
        for (int j = 0; j < monthly_solar_radiation[i].size(); j++) {
            if (monthly_solar_radiation[i].size() == 0) //if this month is 0, it means no data
                monthly_solar_radiation_sum.push_back(0);//then we push back 0 into our vector
            else//if not 0, means this month has data, we get solar radiation sum for this month
                solar_radiation_sum += monthly_solar_radiation[i][j];
        }
        monthly_solar_radiation_sum.push_back(solar_radiation_sum);//add sum into our result vector
        solar_radiation_sum = 0;//empty this month's sum for next month calculation
    }

    return monthly_solar_radiation_sum;//return our result vector
}

void WindLogManager::ConvertUnitForSolarRadiation(Vector<float> &monthly_solar_radiation_sum) {
    for (int i = 0; i < monthly_solar_radiation_sum.size(); ++i)//convert unit as assignment required,
        monthly_solar_radiation_sum[i] /= 6000;//formula is state in assignment sheet notes part
}

void WindLogManager::PrintSolarRadiationInfo(const Vector<float> &monthly_solar_radiation_sum, int year) {
    cout << year << endl;//print out the result as required format
    for (int i = 0; i < monthly_solar_radiation_sum.size(); ++i) {
        if (monthly_solar_radiation_sum[i] == 0) {
            cout << get_English_month_word(i + 1) << ": No Data" << endl;
        } else {
            cout << get_English_month_word(i + 1) << ": " << setprecision(4)
                 << monthly_solar_radiation_sum[i] << " kWh/m^2" << endl;
        }
    }
}

bool WindLogManager::IsYearValid(int year) {
    for (int i = 0; i < wind_log.size(); ++i) {//traverse file
        if (wind_log[i].getDate().getYear() == year)//if we find this year
            return true;//return true
    }
    return false;//if not find this year, return false
}

void WindLogManager::WriteIntoCSV(int year,
                                  const Vector<float> &monthly_wind_speed_mean,
                                  const Vector<float> &monthly_wind_speed_sample_stdev,
                                  const Vector<float> &monthly_temperature_mean,
                                  const Vector<float> &monthly_temperature_sample_stdev,
                                  const Vector<float> &monthly_solar_radiation_sum) {
    ofstream ofs("data\\WindTempSolar.csv");//write data into WindTempSolar.csv as required format under data dir

    if (!IsYearValid(year)) {//if the file do not have this year, it means definitely no data this year
        ofs << year << endl;
        ofs << "No Data" << endl;
    } else {//the year has data, write into our csv file as required format
        ofs << year << endl;
        for (int i = 0; i < 12; ++i) {
            //if this month has data
            if (monthly_wind_speed_mean[i] != 0 && monthly_wind_speed_sample_stdev[i] != 0 &&
                monthly_temperature_mean[i] != 0 && monthly_temperature_sample_stdev[i] != 0 &&
                monthly_solar_radiation_sum[i] != 0) {//e.g.  March,data(data),data(data),data
                ofs << get_English_month_word(i + 1) << ','
                    << setprecision(3) << monthly_wind_speed_mean[i] << "(" << setprecision(3)
                    << monthly_wind_speed_sample_stdev[i] << ")" << ','
                    << setprecision(3) << monthly_temperature_mean[i] << "(" << setprecision(3)
                    << monthly_temperature_sample_stdev[i] << ")" << ','
                    << setprecision(4) << monthly_solar_radiation_sum[i] << endl;
            }
            if (monthly_wind_speed_mean[i] == 0 && monthly_temperature_mean[i] != 0 &&
                monthly_solar_radiation_sum[i] != 0) {//e.g.  March,empty(empty),data(data),data
                ofs << get_English_month_word(i + 1) << ','
                    << " " << ','
                    << setprecision(3) << monthly_temperature_mean[i] << "(" << setprecision(3)
                    << monthly_temperature_sample_stdev[i] << ")" << ','
                    << setprecision(4) << monthly_solar_radiation_sum[i] << endl;
            }
            if (monthly_wind_speed_mean[i] != 0 && monthly_temperature_mean[i] == 0 &&
                monthly_solar_radiation_sum[i] != 0) {//e.g.  March,data(data),empty(empty),data
                ofs << get_English_month_word(i + 1) << ','
                    << setprecision(3) << monthly_wind_speed_mean[i] << "(" << setprecision(3)
                    << monthly_wind_speed_sample_stdev[i] << ")" << ','
                    << " " << ','
                    << setprecision(4) << monthly_solar_radiation_sum[i] << endl;
            }
            if (monthly_wind_speed_mean[i] != 0 && monthly_temperature_mean[i] != 0 &&
                monthly_solar_radiation_sum[i] == 0) {//e.g.  March,data(data),data(data),empty
                ofs << get_English_month_word(i + 1) << ','
                    << setprecision(3) << monthly_wind_speed_mean[i] << "(" << setprecision(3)
                    << monthly_wind_speed_sample_stdev[i] << ")" << ','
                    << setprecision(3) << monthly_temperature_mean[i] << "(" << setprecision(3)
                    << monthly_temperature_sample_stdev[i] << ")" << ','
                    << " " << endl;
            }
            if (monthly_wind_speed_mean[i] == 0 && monthly_temperature_mean[i] == 0 &&
                monthly_solar_radiation_sum[i] != 0) {//e.g.  March,empty(empty),empty(empty),data
                ofs << get_English_month_word(i + 1) << ','
                    << " " << ','
                    << " " << ','
                    << setprecision(4) << monthly_solar_radiation_sum[i] << endl;
            }
            if (monthly_wind_speed_mean[i] == 0 && monthly_temperature_mean[i] != 0 &&
                monthly_solar_radiation_sum[i] == 0) {//e.g.  March,empty(empty),data(data),empty
                ofs << get_English_month_word(i + 1) << ','
                    << " " << ','
                    << setprecision(3) << monthly_temperature_mean[i] << "(" << setprecision(3)
                    << monthly_temperature_sample_stdev[i] << ")" << ','
                    << " " << endl;
            }
            if (monthly_wind_speed_mean[i] != 0 && monthly_temperature_mean[i] == 0 &&
                monthly_solar_radiation_sum[i] == 0) {//e.g.  March,data(data),empty(empty),empty
                ofs << get_English_month_word(i + 1) << ','
                    << setprecision(3) << monthly_wind_speed_mean[i] << "(" << setprecision(3)
                    << monthly_wind_speed_sample_stdev[i] << ")" << ','
                    << " " << ','
                    << " " << endl;
            }
            if (monthly_wind_speed_mean[i] == 0 && monthly_temperature_mean[i] == 0 &&
                monthly_solar_radiation_sum[i] == 0) {//e.g.  March,empty(empty),empty(empty),empty
                ofs << get_English_month_word(i + 1) << ','
                    << " " << ','
                    << " " << ','
                    << " " << endl;
            }
        }
    }

    ofs.close();
    //tell user we made it!
    cout << "All data in " << year << " has been successfully loaded into 'WindTempSolar.csv'!" << endl;
}
