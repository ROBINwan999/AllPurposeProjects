This is a readme file, it tells you what file does this folder have and what does they do.
---------------------------------------------------------------------------------------------------------------------------------------
This folder contains the following files:
- Assignment1
- evaluation
- external_document_pdf_version
- high_level_uml
- low_level_uml
- README
---------------------------------------------------------------------------------------------------------------------------------------
what do these files do:

Assignment 1:
this is the complete codeblock project, which contains all the files needed to run the program,
doxygen output html is also inside this folder, it is under the "html" folder.
all the input data is from csv files, and all csv file are under a dir called "data"
"data" dir also has a txt file called "file_name", it contains all the csv file names that need to be read into the program
The program can read as many CSV files as it is provided. 
If provided with 2 CSV filenames, then they can both be read in. If only 1 then 1 gets read in. 
If you want to change or add or delete the CSV filename (for testing purposes) then you are be able to.
Just change the content in the "file_name" txt file.
"WindTempSolar.csv" is the output csv file, your can ignore it or even delete it. Everytime you choose menu option 4,
program will create or update a new "WindTempSolar.csv" file.

Evaluation:
this is the "evaluation.txt" file, as the required

external_document_pdf_version:
this is the external document pdf version, it contains picture of UML both high level and low level,
written rationale for design with data dictionary, algorithms, testing plan and result.

high_level_uml:
a high level diagram uml file

low_level_uml:
a low level diagram uml file
---------------------------------------------------------------------------------------------------------------------------------------
How the program works:

1. open the "Assignment1.cbp" file, it's under the Assignment1 folder, use your codeblocks to open it

2. click the build and run button in your codeblocks, it is a little green triangle one

3. Wait for a while, the terminal will appear, waiting for the program to compile and execute, during which there will be a prompt 
message telling you which files the program is loading

4. If the file name is wrong or the file does not exist, the program will end, please check whether the file name in "file_name" is correct

5. After the file data is loaded successfully, the menu option will appear, and you can make choices according to the prompt information. 
For example, after selecting 2, enter the year, and the relevant information will be printed. During this period,  you just need to enter 
the number on the keyboard and press enter.

6. Each time a function is completed, the terminal will prompt you to press any key to continue. At this time, you can press any key, 
the terminal will clear the screen, you can continue to use it, and your terminal will not looks messy because of the last output.

7. When you want to exit, just press 5, the program will finish running

8. If you accidentally input a number that is not an option, or input something that is not a number, 
the program will responds accordingly, such as letting you enter again or finish running.











